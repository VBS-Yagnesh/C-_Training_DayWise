﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{        // To Display Data from table on pressing the button
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connection = "Data Source = 192.168.1.230; Initial Catalog = Freshers_Training2022; Persist Security Info = True; User ID = trainee2022; Password = trainee@2022";
            SqlConnection bottle = new SqlConnection(connection);
            bottle.Open();
            string Query = "Select * from y_o_tar";
            SqlDataAdapter adapter = new SqlDataAdapter(Query, bottle);
            DataTable phone = new DataTable("Hello");
            adapter.Fill(phone);
            dataGridView1.DataSource = phone;
            //dataGridView1.DataBind();
            bottle.Dispose();
            bottle.Close();

        }
    }
}
