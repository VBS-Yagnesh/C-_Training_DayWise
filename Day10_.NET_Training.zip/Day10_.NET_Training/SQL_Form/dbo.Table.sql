﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT PRIMARY KEY
)
