﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ_To_Object
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] names = {"Lord of Rings",
                            "Theory of Everything",
                            "Brief History of Time",
                            "Harry Potter",
                            "Study in Casket"};
            IEnumerable<string> AllTimeFavBooks = from name in names
                                                  where name.Length > 5
                                                  select name;
            foreach(var name in AllTimeFavBooks)
            {
                textBox1.AppendText(name + "\n");
                richTextBox1.AppendText(name + "\n");
            }
        }
    }
}
