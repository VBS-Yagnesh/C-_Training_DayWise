﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data.Linq.SqlClient;

namespace LINQ_To_SQL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connection = "Data Source = 192.168.1.230; Initial Catalog = AdventureWorks2017; Persist Security Info = True; User ID = trainee2022; Password = trainee@2022";
            DataContext db = new DataContext(connection);
            Table<Contacts> cont = db.GetTable<Contacts>();  //Retrieving data from database and inserting in table
            var query = from c in cont
                        where c.Title == "Mr."
                        orderby c.FirstName
                        select c;
            foreach(var item in query)
            {
                richTextBox1.AppendText(item.Title + item.FirstName + item.LastName);
            }
        }
    }
    [Table (Name= "Person.Person")]
    public class Contacts
    {
        [Column]
        public string Title;
        [Column]
        public string FirstName;
        [Column]
        public string LastName;
    }
}
