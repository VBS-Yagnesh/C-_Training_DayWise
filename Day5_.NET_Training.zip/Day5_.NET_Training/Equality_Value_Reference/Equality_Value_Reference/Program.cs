﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equality_Value_Reference
{
    public struct MyStruct
    {
        public string Name { get; set; }
        public string Subject { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Students stud1 = new Students { ID = 1, Name = "Mike", Subject = "Mathematics" };
            Students stud2 = new Students { ID = 2, Name = "Mike", Subject = "Mathematics" };
            Students stud3 = stud1;

            Console.WriteLine("Checking equality with '=': ");
            Console.WriteLine(stud1 == stud2);
            Console.WriteLine(stud1 == stud3);

            Console.WriteLine("Checking equality with 'equals ': ");
            Console.WriteLine(stud1.Equals(stud2));
            Console.WriteLine(stud1.Equals(stud3));

            Console.WriteLine("Checking equality with reference value: ");
            Console.WriteLine(Object.ReferenceEquals(stud1, stud2));
            Console.WriteLine(Object.ReferenceEquals(stud1, stud3));

            Console.WriteLine("HashCode of stud1: " + stud1.GetHashCode());
            Console.WriteLine("HashCode of stud2: " + stud2.GetHashCode());
            Console.WriteLine("HashCode of stud3: " + stud3.GetHashCode());
        }
    }
}
