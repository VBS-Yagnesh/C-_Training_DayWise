﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace User_Defined_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Marks obj = new Marks();
            Console.WriteLine("Enter Marks: ");
            obj.mark = Convert.ToInt32(Console.ReadLine());

            try
            {
                obj.Getmarks();
            }
            catch(MarksException e)
            {
                Console.WriteLine("Work Hard !! : {0} {1}", e.Message, e.StackTrace);
            }
        }
    }
}
