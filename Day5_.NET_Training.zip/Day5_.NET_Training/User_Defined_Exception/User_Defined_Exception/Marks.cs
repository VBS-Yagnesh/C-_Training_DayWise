﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace User_Defined_Exception
{
    public class MarksException : Exception
    {
        public MarksException(string message) : base(message)
        {

        }

    }
    public class Marks
    {
       public int mark { get; set; }
        public void Getmarks()
        {
            if (mark < 50)
            {
                throw (new MarksException("LessMarksException"));
            }
            else
            {
                Console.WriteLine("Marks: {0}", mark);
            }
        }
    }
}
