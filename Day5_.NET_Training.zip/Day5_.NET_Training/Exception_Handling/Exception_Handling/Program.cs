﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Handling 
{
    class Program : System.Exception
    {
        static void Main(string[] args)
        {
            try
            {
                int[] arr = { 10, 5, 3, 6 };
                for(int i = 0; i<4; i++)
                {
                    Console.WriteLine(arr[i]);
                }
                Console.WriteLine("Exception: ");
                Console.WriteLine(arr[6]);
            }
            catch  (IndexOutOfRangeException e)
            {
                Console.WriteLine("Out of range exception has occures: {0} {1}", e.Message, e.StackTrace);
            }
        }
    }
}
