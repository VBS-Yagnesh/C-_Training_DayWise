﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Globalization;
using System.Threading;
using System.Text;
using System.Threading.Tasks;

namespace Hash_Table_Non_Generic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Hashtable newhash = new Hashtable();

            newhash.Add(1, "Hello !");
            newhash.Add(2, 3.1417);
            newhash.Add(3, "1 to the 2");
            newhash.Add(4, null);

            foreach (DictionaryEntry item in newhash) // DictionaryEntry retrieves key value pair
            {
                Console.WriteLine("Key: {0} and it's value is: {1}", item.Key, item.Value);
            }
            Console.WriteLine("-----------");
            Console.WriteLine(newhash.Contains(3)); // Contains search for specific key
            Console.WriteLine(newhash.ContainsValue(null)); // ContainsValue search for specific value
        }
    }
}
