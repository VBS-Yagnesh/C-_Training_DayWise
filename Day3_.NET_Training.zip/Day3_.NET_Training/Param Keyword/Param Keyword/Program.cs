﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Param_Keyword
{
    internal class Program
    {
        public static int Result(params int[] arr) // Param Keyword is used when no. of arguements are unknown.
                                                   // It takes variable no. of arguements
        {
            int total = 0;
           // foreach (var i in arr)
            for(int i=0; i<arr.Length; i++)
            {
                total += arr[i];
                
            }
            return total;
        }
        static void Main(string[] args)
        {
           
            int num = Result(8, 10, 2, 6);
            Console.WriteLine("Sum is: " + num);
        }
    }
}
