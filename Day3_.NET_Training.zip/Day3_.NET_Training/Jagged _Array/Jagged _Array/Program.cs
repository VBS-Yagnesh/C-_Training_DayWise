﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jagged__Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] jag = new int[3][]; // Declaring no. of rows

            jag[0] = new int[4] { 20, 18, 17, 15 };
            jag[1] = new int[3] { 8, 4, 22 };
            jag[2] = new int[6] { 40, 36, 28, 32, 10, 2 };

            for(int i=0; i<jag.Length; i++)
            {
                Console.Write("Row({0}): ", i+1); // Printing row number
                for(int j=0; j<jag[i].Length; j++)
                {
                    Console.Write(jag[i][j] + "\t"); // Printing elements of each row
                }
                Console.WriteLine();
            }
        }
    }
}
