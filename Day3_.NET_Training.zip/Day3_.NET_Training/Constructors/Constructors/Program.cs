﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Students stud1 = new Students();
            Console.WriteLine("Student name is {0} and his subject is: {1} ", stud1.name, stud1.subject);

            Students stud2 = new Students("Anthony", "Maths");
            Console.WriteLine("Student name is {0} and his subject is: {1} ", stud2.name, stud2.subject);

            Students stud3 = new Students("John", "Economics");
            Console.WriteLine("Student name is {0} and his subject is: {1} ", stud3.name, stud3.subject);
        }
    }
}
