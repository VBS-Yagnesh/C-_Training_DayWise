﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors
{
   public class Students
    {
        public string name;
        public string subject;
        public Students(string name, string subject) // parametrised constructor
        {
            this.name = name;
            this.subject = subject;
        }

        public Students()
        {
            name = "Mike";
            subject = "History"; 
        }
    }
}
