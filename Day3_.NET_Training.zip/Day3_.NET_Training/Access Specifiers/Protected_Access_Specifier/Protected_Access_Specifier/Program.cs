﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Protected_Access_Specifier
{
     class Number
    {
        protected int num;
        public void SetValue(int n)
        {
            num = n;
        }
        
    }
    class Child : Number
    {
        Number numb1 = new Number();
        public int GetValue()
        {
            return num;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Child chill = new Child();
            chill.SetValue(10);
            Console.WriteLine("Number is: " + chill.GetValue());
        }
    }
}
