﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Protected_Internal
{
    class Program : Parent
    {
        static void Main(string[] args)
        {
            Parent par2 = new Parent();
            par2.num = 8;
            Console.WriteLine("Value: " + par2.num);
            
        }
    }
}
