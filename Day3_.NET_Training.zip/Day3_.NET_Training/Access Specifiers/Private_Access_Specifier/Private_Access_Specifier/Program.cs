﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_Access_Specifier
{
    class Parent
    {
        private int num;
        public void SetValue(int n)
        {
            num = n;
        }
        public int GetValue()
        {
            return num;
        }
    }

    class Child : Parent
    {
        public void ShowValue()
        {
             // return num; // Gives an error because of private protection
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Parent par = new Parent();
            par.SetValue(8);
            Console.WriteLine("Number is: " + par.GetValue());
        }
    }
}
