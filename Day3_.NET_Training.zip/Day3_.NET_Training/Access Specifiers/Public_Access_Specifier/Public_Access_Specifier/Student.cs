﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Public_Access_Specifier
{
    public class Student
    {
        public int roll;
        public string name;

        public Student(int r, string n) // Constructor
        {
            roll = r;
            name = n;
        }

        public int studentroll() // Method
        {
            return roll;
        }
        public string studentname() // Method
        {
            return name;
        }
    }
}
