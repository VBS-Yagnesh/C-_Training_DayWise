﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Public_Access_Specifier
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student stud1 = new Student(1,"Helena");
            Console.WriteLine("Fist Student: {0}, {1}", stud1.roll, stud1.name);
            stud1.roll = 2;
            stud1.name = "Joseph";
            Console.WriteLine("Second Student: {0}, {1}", stud1.roll, stud1.name);
        }
    }
}
