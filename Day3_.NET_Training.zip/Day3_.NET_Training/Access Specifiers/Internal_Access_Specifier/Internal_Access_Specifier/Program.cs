﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Internal_Access_Specifier
{
    internal class Complex
    {
        public int real;
        public int img;

        public void SetData(int r, int i)
        {
            real = r;
            img = i;
        }
        public void Display()
        {
            Console.WriteLine("Real part: {0} and imaginary part is: {1}", real, img);
           
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Complex comp = new Complex();
            
            comp.SetData(4,6);
            comp.Display();
            
        }
    }
}
