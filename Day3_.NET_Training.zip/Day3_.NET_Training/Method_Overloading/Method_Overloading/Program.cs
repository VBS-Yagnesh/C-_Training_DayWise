﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Method_Overloading
{
    class Program
    {
        
        public int Num(int a, int b)
        {
            int c = a + b;
            return c;

        }

        public double Num(double a, double b)
        {
           double c = a + b;
            return c;
        }
        public double Num(double a, double b, double d) 
        {
            double c = a + b - d;
            return c;
        }
        static void Main(string[] args)
        {
            Program prog1 = new Program();
            int res1 = prog1.Num(8, 7);
            Console.WriteLine("Sum is: " + res1);

            Program prog2 = new Program();
            double res2 = prog2.Num(4.32, 5.78);
            Console.WriteLine("Sum 2 is: " + res2);

            Program prog3 = new Program();
            double res3 = prog3.Num(9.9, 6.54, 2.567);
            Console.WriteLine("Sum is 3: " + res3);
           
        }
    }
}
