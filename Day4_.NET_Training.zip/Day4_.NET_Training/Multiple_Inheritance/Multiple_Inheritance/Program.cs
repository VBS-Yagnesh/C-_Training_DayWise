﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiple_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator cc = new Calculator();
            Console.WriteLine(cc.add(9, 6));
            Console.WriteLine(cc.add(7.3f, 4.24f));
            Console.WriteLine(cc.sub(3,13));
            Console.WriteLine(cc.sub(3.87f, 9.211f));
        }
    }
}
