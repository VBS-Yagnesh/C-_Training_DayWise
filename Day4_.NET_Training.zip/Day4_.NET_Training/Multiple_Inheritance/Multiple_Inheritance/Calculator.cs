﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiple_Inheritance
{
    internal interface IBasicCalc
    {
        int add(int a, int b);
        int sub(int a, int b);
    }
    interface IFloatCalc
    {
        float add(float a, float b);
        float sub(float a, float b);
    }
    class Calculator : IBasicCalc, IFloatCalc
    {
        public int add(int a, int b)
        {
            Console.WriteLine("Add from IBasicCalc: " );
            return a + b;
        }
        public int sub(int a, int b)
        {
            Console.WriteLine("Subtract from IBasic Calc: ");
            return b - a;
        }
        public float add(float a, float b)
        {
            Console.WriteLine("Add from IFloatCalc: ");
            return a + b;
        }
        public float sub(float a, float b)
        {
            Console.WriteLine("Subtract from IFloatCalc: ");
            return b - a;
        }
    }
    
}
