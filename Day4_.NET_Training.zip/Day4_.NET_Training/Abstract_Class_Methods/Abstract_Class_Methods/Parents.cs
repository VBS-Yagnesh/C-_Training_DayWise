﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Class_Methods
{
    public abstract class Parents
    {
        public abstract void parent();
    }
    public class Child1 : Parents
    {
        public override void parent()
        {
            Console.WriteLine("Child 1 message");
        }
    }
    public class Child2 : Parents
    {
        public override void parent()
        {
            Console.WriteLine("Child 2 message");
        }
    }
}
