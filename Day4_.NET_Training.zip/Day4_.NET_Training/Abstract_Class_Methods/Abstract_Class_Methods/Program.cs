﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Class_Methods
{
    
    
    class Program
    {
        static void Main(string[] args)
        {
            Parents parr; // Creating object of abstract class. It cannot be instantiated.
            parr = new Child1(); // Instantiating Child1 class.
            parr.parent();

            parr = new Child2(); // Instantiating Child2 class.
            parr.parent();
        }
    }
}
