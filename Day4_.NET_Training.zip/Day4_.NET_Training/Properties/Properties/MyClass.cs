﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    public class MyClass
    {
        //private int n;
        //public int Klass
        //{
        //    get
        //    {
        //        return n;
        //    }
        //    set
        //    {
        //        n = value;
        //    }
        //}

        private static int n;
        public static int Klass
        {
            get
            {
                return n;
            }
            set
            {
                n = value;
            }
        }
    }
}
