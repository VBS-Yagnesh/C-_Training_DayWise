﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //MyClass myc = new MyClass();
            //myc.Klass = 8;
            //Console.WriteLine(myc.Klass);

            MyClass.Klass = 12;
            Console.WriteLine(MyClass.Klass);
        }
    }
}
