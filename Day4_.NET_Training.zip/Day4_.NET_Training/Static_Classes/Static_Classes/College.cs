﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Classes
{
    static class College
    {
        public static string CollegeName;
        public static string CollegeCity;
        public static string CollegeAddress;

        private static string EstdYr = "1921";

        public static string YearEstd
        {
            get
            { return EstdYr; }
            set
             {EstdYr = value; }
        }

         static College()
        {
            CollegeName = "Punjab Engineering College";
            CollegeCity = "Chandigarh";
            CollegeAddress = "Sector 12";
        }
    }
}
