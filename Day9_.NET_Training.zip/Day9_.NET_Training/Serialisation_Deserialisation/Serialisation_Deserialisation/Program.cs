﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serialisation_Deserialisation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Students stud = new Students();
            stud.roll = 1;
            stud.name = "Mike";

            IFormatter format = new BinaryFormatter();
            Stream stem1 = new FileStream("C:\\Users\\Yagnesh Sharma\\OneDrive\\Desktop\\Training\\.NET\\Demos_Training\\Demo_Multithreading_2\\Demo_Multithreading_2\\Dams.txt", FileMode.Create, FileAccess.Write);

            // IFormatter: Provides functionality for formatting seriealised objects
            // Stream: Provides generic view of sequence of bytes

            format.Serialize(stem1, stud); // Serialises the objects to the stream of bytes
            Console.WriteLine("Serialisation Successful");
            stem1.Close();

            Stream stem2 = new FileStream("C:\\Users\\Yagnesh Sharma\\OneDrive\\Desktop\\Training\\.NET\\Demos_Training\\Demo_Multithreading_2\\Demo_Multithreading_2\\Dams.txt", FileMode.Open, FileAccess.Read);
            Students stud2 = (Students)format.Deserialize(stem2); // TypeCasting. Deserialises the byte of streams back to objects
            Console.WriteLine("Roll No.: " + stud2.roll);
            Console.WriteLine("Name: " + stud2.name);
            Console.WriteLine("Deserialisation Successful");
            stem2.Close();
        }
    }
}
