﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Serialisation_Deserialisation
{
    [Serializable]  // Attribute used to add meta data(data about data). Declarative tag. Conveys info at runtime how elements are behaving
    internal class Students
    {
        public int roll { set; get; }
        public string name { set; get; }
    }
}
