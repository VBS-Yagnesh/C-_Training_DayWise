﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace MultiThreading
{
    class Program
    {
        static Thread Fabric;

         static void Fab()
        {
            for(int i=0; i<10; i++)
            {
                Console.WriteLine("Output: " + i);

                if (i == 3)
                {
                    Fabric.Suspend();
                    Console.WriteLine("Suspended");

                }
            }
        }
        static void Main(string[] args)
        {
            Fabric = new Thread(new ThreadStart(Fab));
            Fabric.Start();
            Console.WriteLine("Alive: " + Fabric.IsAlive);
            Console.WriteLine("Current State: " + Fabric.ThreadState);
            Thread.Sleep(3000);
            
            Fabric.Resume();
            Console.WriteLine("Resumed");
        }
    }
}
