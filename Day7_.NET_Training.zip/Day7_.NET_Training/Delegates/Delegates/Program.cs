﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Program
    {
        public delegate void delarious();
        public class Myclass
        {
            public static void Display()
            {
                Console.WriteLine("Delegate 1");
                Console.WriteLine("Display Printed");
            }
            public static void Show()
            {
                Console.WriteLine("Delegate 2");
                Console.WriteLine("Show printed");
            }
            public static void Print()
            {
                Console.WriteLine("Delegate 3");
                Console.WriteLine("Print Printed");
            }
        }
        static void Main(string[] args)
        {
            delarious del1 = Myclass.Display;
            delarious del2 = Myclass.Show;
            delarious del3 = Myclass.Print;
            delarious del4 = del1 + del2;
            del1();
            del2();
            del3();
            Console.WriteLine("Delegte 4: ");
            del4();

        }
    }
}
