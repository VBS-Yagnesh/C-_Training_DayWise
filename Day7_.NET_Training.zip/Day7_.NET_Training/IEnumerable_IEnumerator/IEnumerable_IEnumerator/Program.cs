﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerable_IEnumerator
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> Weeks = new List<string> { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };

            Console.WriteLine("Implementing IEnumerable");
            IEnumerable<string> Numb = Weeks; // Creating IEnumerable strings
            Console.WriteLine("Weekdays: ");
            foreach(var item in Numb)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Implementing IEnumerator");
            IEnumerator<string> Numt = Weeks.GetEnumerator(); // Creating IEnumerator of strings
            // GetEnumerator returns an enumerator that iterates through list
            Console.WriteLine("Weekdays: ");
            foreach(var prod in Weeks)
            {
                Console.WriteLine(prod);
            }
        }
    }
}
