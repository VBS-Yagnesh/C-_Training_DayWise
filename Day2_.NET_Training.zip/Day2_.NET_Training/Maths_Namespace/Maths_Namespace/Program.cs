﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maths_Namespace
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Square Root: " + Math.Sqrt(144));
            Console.WriteLine("Min among 40, 80: " + Math.Min(40, 80));
            Console.WriteLine("Absolute value of -5.99: " + Math.Abs(-5.99));
            Console.WriteLine("Round of 9.99: " + Math.Round(9.99));
            Console.WriteLine("Absolute of -214789: " + Math.Abs(-214789));
        }
    }
}
