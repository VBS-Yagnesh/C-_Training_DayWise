﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ternary_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ternary operator");
            int x = 5, y = 8;
            Console.WriteLine("X is: " + x);
            Console.WriteLine("Y is: " + y);
            var res = x > y ? "X is Greater than Y" :
                        x < y ? "X is smaller than Y" :
                            x == y ? "X is equal to y" : "No Result";
            Console.WriteLine(res);
        }
    }
}
