﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace Date_Time
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Date Time Example");
            DateTime DateToday = new DateTime(2022, 09, 02, 12, 30, 48);

            Console.WriteLine("Year: " + DateToday.Year);
            Console.WriteLine("Month: " + DateToday.Month);
            Console.WriteLine("Date: " + DateToday.Day);
            Console.WriteLine("Hour: " + DateToday.Hour);
            Console.WriteLine("Minute: " + DateToday.Minute);
            Console.WriteLine("Second: " + DateToday.Second);
            Console.WriteLine("-------------");
            Console.WriteLine(DateToday.ToString( "dd/MM/yyyy/hh/mm/ss"));
            Console.WriteLine(DateTime.Now);
            Console.WriteLine("-------------");

            Console.WriteLine("Using thread for diaplaying Time in a Loop");
            for (int i = 0; i < 10; i++)
            {

                Console.WriteLine(DateTime.Now);
                Thread.Sleep(1000);
            }
           


        }
    }
}
