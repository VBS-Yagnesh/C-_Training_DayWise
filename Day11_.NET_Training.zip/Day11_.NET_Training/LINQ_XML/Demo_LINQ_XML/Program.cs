﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Demo_LINQ_XML
{
    class Program
    {
        string path = "C:\\Users\\Yagnesh Sharma\\OneDrive\\Desktop\\Training\\.NET\\Demos_Training\\Demo_LINQ_XML\\Demo_LINQ_XML\\UserDetails.xml";
        private void GETXMLData() {
            XDocument doc = XDocument.Load(path);

            var part = from User in doc.Descendants("User")
                       select new
                       {
                           ID = Convert.ToInt32(User.Attribute("ID").Value),
                           Name = User.Element("Name").Value
                       };
            foreach (var item in part)
            {
                Console.WriteLine(item.ID + " " + item.Name);
                // Console.WriteLine("Hello");
            }
        }
        private void InsertXMLData(string name)
        {
            try
            {
                XDocument myXML = XDocument.Load(path);
                XElement newUser = new XElement("User", new XElement("Name", name));
                var LastUser = myXML.Descendants("User").Last();
                int newID = Convert.ToInt32(LastUser.Attribute("ID").Value);

                newUser.SetAttributeValue("ID", newID+1); // Setting Attribute
                myXML.Element("Users").Add(newUser); // Adding new Element
                myXML.Save(path);
            }
            catch (Exception)
            {

            }
            
        }
        private void ModifyXMLData(string name, int Id)
        {
            try
            {
                XDocument testXML = XDocument.Load(path);
                XElement NUser = testXML.Descendants("User").Where(n => n.Attribute("ID").Value.Equals(Id.ToString())).FirstOrDefault();
                NUser.Element("Name").Value = name;
                testXML.Save(path);
            }
            catch (Exception)
            {

            }
            // private void modify(string name, int ID, int newID)
            //XDocument myXML = XDocument.Load(path);
            //var Students = from Student in myXML.Descendants("Participant")
            //               where Student.Attribute("ID").Value == Id.ToString()
            //               select Student;

            //foreach (var item in Students)
            //{
            //    item.Attribute("ID").SetValue(newID);
            //    item.Element("Name").SetValue(name);
            //}
            //myXML.Save();
            //myXML.Save(path);
        }

        private void DeleteXMLData(int Id)
        {
            try
            {
                XDocument testxml = XDocument.Load(path);
                XElement XUser = testxml.Descendants("User").Where(n => n.Attribute("ID").Value.Equals(Id.ToString())).FirstOrDefault();
                XUser.Remove();
                testxml.Save(path);
            }
            catch (Exception)
            {

            }
        }
        static void Main(string[] args)
        {
            // Step 1: Connection String
            //string path = "C:\\Users\\Yagnesh Sharma\\OneDrive\\Desktop\\Training\\.NET\\Demos_Training\\Demo_LINQ_XML\\Demo_LINQ_XML\\UserDetails.xml";

            Program obj1 = new Program();
            //obj1.GETXMLData();

            //obj1.InsertXMLData("Hussey");
            //obj1.InsertXMLData("Andrew");
            //obj1.GETXMLData();

            //obj1.ModifyXMLData("Kevin", 9);
            //obj1.GETXMLData();
            obj1.DeleteXMLData(5);
            Console.WriteLine("Deleted something");
            obj1.GETXMLData();
        }
    }
}
